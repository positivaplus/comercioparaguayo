Your personal files are encrypted! Encryption was produced using a unique public key RSA-2048 generated for this computer.

To decrypt files you need to obtain the private key.

The single copy of the private key, which will allow to decrypt the files, located on a secret server at the Internet. After that, nobody and never will be able to restore files...

To obtain the private key and php script for this computer, which will automatically decrypt files, you need to pay 0.5 bitcoin(s) (~210 USD).
Without this key, you will never be able to get your original files back.


______________________________________________

!!!!!!!!!!!!!!!!!!!!! PURSE FOR PAYMENT(ALSO AUTHORIZATION CODE): 1MZ6a2bnxSzgcjGKXqjSxiaj1uVrUrrutM !!!!!!!!!!!!!!!!!!!!!
WEBSITE: http://l4zd5dbd74wnle3l.onion.to

INSTRUCTION FOR DECRYPT:

After you made payment, you should go to website http://l4zd5dbd74wnle3l.onion.to
Use purse for payment as ur authorization code (1MZ6a2bnxSzgcjGKXqjSxiaj1uVrUrrutM).
If you already did the payment, you will see decryption pack available for download,
inside decryption pack - key and script for decryption, so all what you need just upload and run that script ( for example: http://http://kannel-cm.com/decrypt.php )

Also, at this website you can communicate with our supports and we can help you if you have any troubles,
but hope you understand we will not answer at any messages if you not able to pay.

!!!P.S. Our system is fully automatic, after payment you will receive you're decrypt pack IMMEDIATELY!!!

FAQ:
Q: How can I pay?
A: We are accept only bitcoins.

Q: Where to buy bitcoins?
A: We can't help you to buy bitcoins, but you can check link below: https://en.bitcoin.it/wiki/Buying_Bitcoins_(the_newbie_version)

Q: I already bought bitcoins, where i should send it.
A: 1MZ6a2bnxSzgcjGKXqjSxiaj1uVrUrrutM

Q: What gonna happen after payment?
A: Download button for decryption pack will be available after you made payment

Q: I pay, but still can't download decryption pack
A: You need to wait 3 confirmations for bitcoin transaction.

Q: How to use decryption pack?
A: Put all files from archive to your server and just run decrpyt.php (example: website.com/decrypt.php)

Q: Can I pay another currency?
A: No.