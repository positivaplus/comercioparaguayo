<?php

/**
 * El Comercio Paraguayo, W3 S.A. - IT Solutions. All Rights Reserved. 2011.
 *
 * @author Endrigo Rivas -  02-feb-2012, 9:23:52.
 * 
 * $Id$
 */
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/template_el_comercio.dwt.php" codeOutsideHTMLIsLocked="false" -->
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <link rel="shortcut icon" href="images/favicon_el_comercio_paraguayo.ico" />
        <!-- InstanceBeginEditable name="doctitle" -->
        <title>El Comercio Paraguayo S.A. - Asegurando su futuro</title>
        <link rel="stylesheet" href="css/lightbox.css" type="text/css" media="screen" />

        <script type="text/javascript" src="js/prototype.js"></script>
        <script type="text/javascript" src="js/scriptaculous.js?load=effects,builder"></script>
        <script type="text/javascript" src="js/lightbox.js"></script>
<!--        <script src="Scripts/swfobject_modified.js" type="text/javascript"></script>-->

        <!-- InstanceEndEditable -->
        <link href="estilos.css" rel="stylesheet" type="text/css" />
        <style type="text/css">
            <!--
            body {
                margin-top: 0px;
                background-image: url(images/img_background.png);
                background-position:center;
                margin-bottom: 0px;
            }
            a:link {
                text-decoration: none;
            }
            a:visited {
                text-decoration: none;
            }
            a:hover {
                text-decoration: underline;
            }
            a:active {
                text-decoration: none;
            }
            -->
        </style>
        <script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script>
        <!-- InstanceBeginEditable name="head" --><!-- InstanceEndEditable -->
    </head>

    <body>
        <table width="778" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
                <th height="110" valign="top" scope="col"><script type="text/javascript">
                    AC_FL_RunContent( 'codebase','http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0','width','778','height','104','src','flash/header','quality','high','pluginspage','http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash','movie','flash/header','wmode','opaque' );//end AC code
                    </script><noscript>
                        <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0" width="778" height="104" >
                            <<param name="wmode" value="opaque">
                                <param name="movie" value="flash/header.swf"/>
                                <param name="quality" value="high"/>
                                <embed  wmode="opaque"src="flash/header.swf" quality="high" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="778" height="104">
                                </embed>
                        </object>
                    </noscript></th>
            </tr>
        </table>
        <table width="778" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
                <td width="580" valign="top"><!-- InstanceBeginEditable name="EditRegion1" -->
                    <a id="first" href="images/lightboxindex.png" rel="lightbox[roadtrip]" rev="http://www.webpagos.com.py" title="Ingresar al Sitio"></a>


                    <table width="580" border="0" cellpadding="0" cellspacing="0">
                        <tr>
                            <td width="194"><img src="images/img_particular.jpg" width="194" height="185" /><img src="images/img_titulo_particular.jpg" width="194" height="60" /></td>
                            <td width="192"><img src="images/img_empresa.jpg" width="192" height="185" /><img src="images/img_titulo_empresa.jpg" width="192" height="60" /></td>
                            <td width="194"><img src="images/img_familia.jpg" width="194" height="185" /><img src="images/img_titulo_familia.jpg" width="194" height="60" /></td>
                        </tr>
                        <tr>
                            <td colspan="3" background="images/img_separadores.png"><table width="580" border="0" cellpadding="0" cellspacing="0">
                                    <tr>
                                        <td colspan="3" valign="top">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td width="193" valign="top"><table width="160" border="0" align="center" cellpadding="0" cellspacing="0">
                                                <tr>
                                                    <td height="150" valign="top"><span class="contenido">Una amplia gama de protecci&oacute;n                                 de riesgos, de forma a brindar las mas completas                                 posibilidades de cobertura en favor de sus apreciados                                 clientes. Algunos intereses particulares que ofrecemos a nuestros clientes son:</span></td>
                                                </tr>
                                                <tr>
                                                    <td><table width="155" border="0" cellpadding="0" cellspacing="0">
                                                            <tr>
                                                                <td width="10" height="18"><img src="images/vineta_azul.gif" width="4" height="7" /></td>
                                                                <td width="145" class="contenido">Autom&oacute;viles</td>
                                                            </tr>
                                                            <tr>
                                                                <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                                                                <td class="contenido">Cauciones</td>
                                                            </tr>
                                                            <tr>
                                                                <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                                                                <td class="contenido">Accidentes</td>
                                                            </tr>
                                                            <tr>
                                                                <td height="14" valign="bottom"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                                                                <td rowspan="2" class="contenido">Responsabilidad Civil hacia terceros</td>
                                                            </tr>
                                                            <tr>
                                                                <td height="9">&nbsp;</td>
                                                            </tr>
                                                            <tr>
                                                                <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                                                                <td class="contenido">Entre otros seguros</td>
                                                            </tr>
                                                        </table></td>
                                                </tr>
                                            </table></td>
                                        <td width="193" valign="top"><table width="160" border="0" align="center" cellpadding="0" cellspacing="0">
                                                <tr>
                                                    <td height="102" valign="top" class="contenido">Para todas las empresas interesadas en precautelar sus intereses, le ofrecemos una amplia variedad de servicios para proteger a su compa&ntilde;&iacute;a:</td>
                                                </tr>
                                                <tr>
                                                    <td><table width="155" border="0" cellpadding="0" cellspacing="0">
                                                            <tr>
                                                                <td width="10" height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                                                                <td width="145" class="contenido">Incendios</td>
                                                            </tr>
                                                            <tr>
                                                                <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                                                                <td class="contenido">Transportes</td>
                                                            </tr>
                                                            <tr>
                                                                <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                                                                <td class="contenido">Fidelidad de Empleados</td>
                                                            </tr>
                                                            <tr>
                                                                <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                                                                <td class="contenido">Valores de Tr&aacute;nsito</td>
                                                            </tr>
                                                            <tr>
                                                                <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                                                                <td class="contenido">Seguro T&eacute;cnico</td>
                                                            </tr>
                                                            <tr>
                                                                <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                                                                <td class="contenido">Seguro de Vida Colectivo</td>
                                                            </tr>
                                                            <tr>
                                                                <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                                                                <td class="contenido">P&oacute;liza Integral Bancaria</td>
                                                            </tr>
                                                        </table></td>
                                                </tr>
                                            </table></td>
                                        <td width="194" valign="top"><table width="160" border="0" align="center" cellpadding="0" cellspacing="0">
                                                <tr>
                                                    <td height="85" valign="top" class="contenido">Nuestra <strong>P&oacute;liza Hogar</strong> ofrece una cobertura combinada de todos los riesgos propios de la casa de una familia:</td>
                                                </tr>
                                                <tr>
                                                    <td><table width="155" border="0" cellpadding="0" cellspacing="0">
                                                            <tr>
                                                                <td width="10" height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                                                                <td width="145" class="contenido">Incendio - Explosi&oacute;n</td>
                                                            </tr>
                                                            <tr>
                                                                <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                                                                <td class="contenido">Robo</td>
                                                            </tr>
                                                            <tr>
                                                                <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                                                                <td class="contenido">Da&ntilde;os por Agua</td>
                                                            </tr>
                                                            <tr>
                                                                <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                                                                <td class="contenido">Roturas de Cristales</td>
                                                            </tr>
                                                            <tr>
                                                                <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                                                                <td class="contenido">Accidentes Personales</td>
                                                            </tr>
                                                            <tr>
                                                                <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                                                                <td class="contenido">Responsabilidad Civil</td>
                                                            </tr>
                                                        </table></td>
                                                </tr>
                                            </table></td>
                                    </tr>
                                    <tr>
                                        <td height="28" colspan="3" align="right" valign="bottom"><img src="images/img_separadores_pie.png" width="573" height="10" /></td>
                                    </tr>
                                </table></td>
                        </tr>
                        <tr>
                            <td colspan="3">&nbsp;</td>
                        </tr>
                    </table>
                    <a href="http://190.211.240.98:85/"><img src="images/restreo.jpg" width="553" height="122" /></a>
                  <!-- InstanceEndEditable --></td>
                <td width="198" valign="top"><table width="198" border="0" cellpadding="0" cellspacing="0">
                        <tr>
                            <td><script type="text/javascript">
                                AC_FL_RunContent( 'codebase','http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0','width','198','height','216','src','flash/menu_principal','quality','high','pluginspage','http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash','movie','flash/menu_principal', 'wmode','opaque' );

                                //end AC code
                                </script><noscript><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0" width="198" height="216">
                                        <param name="wmode" value="opaque">
                                            <param name="movie" value="flash/menu_principal.swf" />
                                            <param name="quality" value="high" />
                                            <embed wmode="opaque" src="flash/menu_principal.swf" quality="high" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="198" height="216"></embed></object></noscript></td>
                        </tr>
                        <tr>
                            <td height="20" background="images/img_puntos_grises.gif">&nbsp;</td>
                        </tr>
                        <tr>
                            <td height="50" valign="top" bgcolor="#E5E5E5"><img src="images/img_titulo_novedades.png" width="198" height="42" /></td>
                        </tr>
                        <tr>
                            <td bgcolor="#E5E5E5"><!-- InstanceBeginEditable name="EditRegion2" -->
                                <table width="170" border="0" align="center" cellpadding="0" cellspacing="0">
                                    <tr>
                                        <td height="30" valign="top"><strong class="titulos_novedades">Responsabilidad Civil Internacional</strong></td>
                                    </tr>
                                    <tr>
                                        <td height="6" valign="top" class="separador"><img src="images/img_separador_novedades.png" width="3" height="3" /></td>
                                    </tr>
                                    <tr>
                                        <td height="88" valign="top">
                                            <p class="contenido_novedades"><strong>Carta Verde: </strong>P&oacute;liza &uacute;nica de seguro de responsabilidad civil en viaje internacional para veh&iacute;culos particulares y/o de paseo (da&ntilde;os causados a personas o cosas no transportadas).</p></td>
                                    </tr>
                                    <tr>
                                        <td height="88" valign="top">
                                            <p class="contenido_novedades"><strong>Carta Azul</strong>: P&oacute;liza &uacute;nica de seguro de responsabilidad civil del transportador carretero en viaje internacional (da&ntilde;os causados a personas o cosas transportadas o no, a excepci&oacute;n de la carga).</p></td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <p class="contenido_novedades"><strong>Da&ntilde;os a la Carga:</strong> P&oacute;liza de responsabilidad civi del transportador carretero en viaje internacional (da&ntilde;os a la carga transportada).</p>
                                        </td>
                                    </tr>

                                </table>
                                <div id="imagen_bancard"></div>
                                <!-- InstanceEndEditable --></td>
                        </tr>
                        <tr>
                            <td height="50" valign="top" bgcolor="#E5E5E5"><img src="images/img_titulo_PAGA-TU-POLIZA.png" width="198" height="42" /></td>
                        </tr>
                        <tr>
                            <td bgcolor="#E5E5E5" height="70">
                                <a href="http://www.webpagos.com.py/"><img src="images/logo-webpagos.png" alt="Ingresar a webpagos"/></a>

                            </td>
                        </tr>
                        <tr>
                    </table></td>
            </tr>
        </table>
        <table width="778" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
                <td height="42" background="images/img_fondo_pie.gif"><table width="650" border="0" align="center" cellpadding="0" cellspacing="0">
                        <tr>
                            <td height="18" align="center" class="datos_pie">Copyright &copy; <?php echo date("Y") ?> - El Comercio Paraguayo S.A. - Oficina Central: Alberdi N&ordm; 453</td>
                        </tr>
                        <tr>
                            <td height="18" align="center"><div class="link_mail"><span class="datos_pie">Telefax.: (+595 21) 492   324 Rastreo   Autom&aacute;tico - Mail: <a href="mailto:elcomercioparaguayo@elcomercioparaguayo.com.py" target="_blank">elcomercioparaguayo@elcomercioparaguayo.com.py</a></span></div></td>
                        </tr>
                    </table></td>
            </tr>
            <tr>
                <td height="46" align="center" valign="top" background="images/img_fondo_pie2.png"><table width="200" border="0" cellpadding="0" cellspacing="0">
                        <tr>
                            <td height="25" valign="bottom"><table width="78" border="0" align="center" cellpadding="0" cellspacing="0">
                                    <tr>
                                        <td width="78" class="datos_pie"><div class="link_mail"><a href="http://www.w3.com.py/" target="_blank">W3 IT Solutions</a></div></td>
                                    </tr>
                                </table></td>
                        </tr>
                    </table></td>
            </tr>

        </table>
        <div id="imagen_bancard"><a href="https://www.bancard.com.py/webbancard/SOL/SelloECommBancard.html?c=rO7x6h.bVEGMA"><img src="images/logo_bancard.jpg" alt="bancard" width="224" height="89" /></a></div>
    </body>
    <!-- InstanceEnd -->
</html>
