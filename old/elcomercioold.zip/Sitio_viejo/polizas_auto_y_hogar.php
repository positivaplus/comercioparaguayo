<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/template_el_comercio.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="shortcut icon" href="images/favicon_el_comercio_paraguayo.ico" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>El Comercio Paraguayo S.A. - Asegurando su futuro</title>
<!-- InstanceEndEditable -->
<link href="estilos.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-top: 0px;
	background-image: url(images/img_background.png);
	background-position:center;
	margin-bottom: 0px;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
-->
</style>
<script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script>
<!-- InstanceBeginEditable name="head" --><!-- InstanceEndEditable -->
</head>

<body>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <th height="110" valign="top" scope="col"><script type="text/javascript">
AC_FL_RunContent( 'codebase','http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0','width','778','height','104','src','flash/header','quality','high','pluginspage','http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash','movie','flash/header','wmode','opaque' );//end AC code
</script><noscript>
<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0" width="778" height="104" >
	  <<param name="wmode" value="opaque">
      <param name="movie" value="flash/header.swf"/>
      <param name="quality" value="high"/>
      <embed  wmode="opaque"src="flash/header.swf" quality="high" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="778" height="104">
      </embed>
    </object>
   </noscript></th>
  </tr>
</table>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="580" valign="top"><!-- InstanceBeginEditable name="EditRegion1" -->
      <table width="580" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td height="95" valign="top"><img src="images/img_polizas.jpg" width="580" height="80" /></td>
        </tr>
        <tr>
          <td><table width="540" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>
                <td height="28" valign="top" class="titulos">P&oacute;lizas</td>
              </tr>
              <tr>
                <td height="10" valign="top" class="separador"><img src="images/img_separador_novedades.png" width="3" height="3" /></td>
              </tr>
              <tr>
                <td><table width="535" border="0" cellpadding="0" cellspacing="0">
                    <tr>
                      <td width="250" valign="top"><table width="240" border="0" cellpadding="0" cellspacing="0">
                        <tr>
                          <td height="40"><table width="200" border="0" cellpadding="0" cellspacing="0">
                            <tr>
                              <td width="58"><img src="images/img_poliza_auto.jpg" width="48" height="20" /></td>
                              <td width="142" class="subtitulos">P&oacute;liza Autos</td>
                            </tr>
                          </table></td>
                        </tr>
                        <tr>
                          <td height="18" valign="top" class="contenido"><strong>P&oacute;liza Seguro Total</strong></td>
                        </tr>
                        <tr>
                          <td><table width="235" border="0" cellpadding="0" cellspacing="0">
                            <tr>
                              <td width="10" height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td width="225" class="contenido">Robo 100%</td>
                            </tr>
                            
                            <tr>
                              <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td class="contenido">Robo parcial de acces.: radio y tasas</td>
                            </tr>
                            <tr>
                              <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td class="contenido">Responsabilidad Civil</td>
                            </tr>
                            
                            <tr>
                              <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td class="contenido">Cobertura para los ocupantes</td>
                            </tr>
                            
                            <tr>
                              <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td class="contenido">Cobertura en el Exterior</td>
                            </tr>
                            
                            <tr>
                              <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td class="contenido">Carta Verde sin costo por 30 dias</td>
                            </tr>
                            <tr>
                              <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td class="contenido">Servicio de Ambulancia</td>
                            </tr>
                            <tr>
                              <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td class="contenido">Servicio de grua</td>
                            </tr>
                            
                          </table></td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                        </tr>
                        <tr>
                          <td height="18" valign="top" class="contenido"><strong>P&oacute;liza Tradicional</strong></td>
                        </tr>
                        <tr>
                          <td><table width="235" border="0" cellpadding="0" cellspacing="0">
                            <tr>
                              <td width="10" height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td width="225" class="contenido">Accidente e incendio 100%</td>
                            </tr>
                            <tr>
                              <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td class="contenido">Robo 75% Sin franquicia</td>
                            </tr>
                            <tr>
                              <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td class="contenido">Responsabilidad Civil</td>
                            </tr>
                            <tr>
                              <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td class="contenido">Cobertura para los ocupantes</td>
                            </tr>
                            <tr>
                              <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td class="contenido">Servicio de Ambulancia</td>
                            </tr>
                            <tr>
                              <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td class="contenido">Servicio de gr&uacute;a</td>
                            </tr>
                            
                          </table></td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                        </tr>
                        <tr>
                          <td height="18" valign="top" class="contenido"><strong>P&oacute;liza Seguro b&aacute;sico</strong></td>
                        </tr>
                        <tr>
                          <td><table width="235" border="0" cellpadding="0" cellspacing="0">
                            <tr>
                              <td width="10" height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td width="225" class="contenido">Da&ntilde;o total</td>
                            </tr>
                            <tr>
                              <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td class="contenido">Robo o hurto total del veh&iacute;culo</td>
                            </tr>
                            <tr>
                              <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td class="contenido">Responsabilidad Civil</td>
                            </tr>
                            <tr>
                              <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td class="contenido">Cobertura para los ocupantes</td>
                            </tr>
                            <tr>
                              <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td class="contenido">Servicio de ambulancia</td>
                            </tr>
                            <tr>
                              <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td class="contenido">Servicio de gr&uacute;a</td>
                            </tr>
                          </table></td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                        </tr>
                      </table></td>
                      <td width="35">&nbsp;</td>
                      <td width="250" valign="top"><table width="240" border="0" cellpadding="0" cellspacing="0">
                        <tr>
                          <td height="40"><table width="200" border="0" cellpadding="0" cellspacing="0">
                              <tr>
                                <td width="35"><img src="images/img_poliza_hogar.jpg" width="25" height="25" /></td>
                                <td width="165" class="subtitulos">P&oacute;liza Hogar</td>
                              </tr>
                          </table></td>
                        </tr>
                        
                        <tr>
                          <td height="18" valign="top" class="contenido"><strong>Incendio - Explosi&oacute;n</strong></td>
                        </tr>
                        <tr>
                          <td><table width="235" border="0" cellpadding="0" cellspacing="0">
                            <tr>
                              <td width="10" height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td width="225" class="contenido">Incendio del edificio y contenido</td>
                            </tr>
                            <tr>
                              <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td class="contenido">Da&ntilde;os por huracan, vendaval, o cicl&oacute;n</td>
                            </tr>
                            <tr>
                              <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td class="contenido">Ca&iacute;da de rayos</td>
                            </tr>
                            <tr>
                              <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td class="contenido">Ca&iacute;da de aeronaves</td>
                            </tr>
                            <tr>
                              <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td class="contenido">Ca&iacute;da de veh&iacute;culos terrestres</td>
                            </tr>
                            <tr>
                              <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td class="contenido">Gastos de salvamento y otros</td>
                            </tr>
                            <tr>
                              <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td class="contenido">Actos vand&aacute;licos</td>
                            </tr>
                            <tr>
                              <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td class="contenido">Da&ntilde;os materiales por tumulto</td>
                            </tr>
                          </table></td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                        </tr>
                        
                        <tr>
                          <td height="18" valign="top" class="contenido"><strong>Robo</strong></td>
                        </tr>
                        <tr>
                          <td><table width="235" border="0" cellpadding="0" cellspacing="0">
                            <tr>
                              <td width="10" height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td width="225" class="contenido">Atraco</td>
                            </tr>
                            <tr>
                              <td height="12" valign="bottom"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td rowspan="2" class="contenido">Da&ntilde;os materiales como consecuencia del robo o su                         tentativa</td>
                            </tr>
                            <tr>
                              <td height="22">&nbsp;</td>
                            </tr>
                            <tr>
                              <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td class="contenido">Cobertura de joyas y alhajas</td>
                            </tr>
                            
                          </table></td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                        </tr>
                        <tr>
                          <td height="18" valign="top" class="contenido"><strong>Da&ntilde;os por Agua</strong></td>
                        </tr>
                        <tr>
                          <td><table width="235" border="0" cellpadding="0" cellspacing="0">
                            <tr>
                              <td width="10" height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td width="225" class="contenido">Roturas de ca&ntilde;erias propias o ajenas</td>
                            </tr>
                            
                          </table></td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                        </tr>
                        <tr>
                          <td height="18" valign="top" class="contenido"><strong>Roturas de Cristales</strong></td>
                        </tr>
                        <tr>
                          <td><table width="235" border="0" cellpadding="0" cellspacing="0">
                            
                            <tr>
                              <td width="10" height="12" valign="bottom"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td width="225" rowspan="2" class="contenido">Ventanas y puertas, espejos adosados a la pared, gastos de colocaci&oacute;n</td>
                            </tr>
                            <tr>
                              <td>&nbsp;</td>
                            </tr>
                            
                          </table></td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                        </tr>
                        <tr>
                          <td height="18" valign="top" class="contenido"><strong>Accidentes Personales</strong></td>
                        </tr>
                        <tr>
                          <td><table width="235" border="0" cellpadding="0" cellspacing="0">
                            <tr>
                              <td width="10" height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td width="225" class="contenido">Muerte</td>
                            </tr>
                            <tr>
                              <td height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td class="contenido">Invalidez permanente</td>
                            </tr>
                            
                          </table></td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                        </tr>
                        <tr>
                          <td height="18" valign="top" class="contenido"><strong>Responsabilidad Civil</strong></td>
                        </tr>
                        <tr>
                          <td><table width="235" border="0" cellpadding="0" cellspacing="0">
                            
                            <tr>
                              <td width="10" height="18"><img src="images/vineta_azul.gif" alt="" width="4" height="7" /></td>
                              <td width="225" class="contenido">Da&ntilde;os causados por terceros</td>
                            </tr>
                          </table></td>
                        </tr>
                        
                        <tr>
                          <td>&nbsp;</td>
                        </tr>
                        
                        
                      </table></td>
                    </tr>
                </table></td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
      </table>
    <!-- InstanceEndEditable --></td>
    <td width="198" valign="top"><table width="198" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td><script type="text/javascript">
AC_FL_RunContent( 'codebase','http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0','width','198','height','216','src','flash/menu_principal','quality','high','pluginspage','http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash','movie','flash/menu_principal', 'wmode','opaque' );

//end AC code
</script><noscript><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0" width="198" height="216">
          <param name="wmode" value="opaque">
          <param name="movie" value="flash/menu_principal.swf" />
          <param name="quality" value="high" />
          <embed wmode="opaque" src="flash/menu_principal.swf" quality="high" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="198" height="216"></embed></object></noscript></td>
      </tr>
      <tr>
        <td height="20" background="images/img_puntos_grises.gif">&nbsp;</td>
      </tr>
      <tr>
        <td height="50" valign="top" bgcolor="#E5E5E5"><img src="images/img_titulo_novedades.png" width="198" height="42" /></td>
      </tr>
      <tr>
        <td bgcolor="#E5E5E5"><!-- InstanceBeginEditable name="EditRegion2" -->
          <table width="170" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td height="18" valign="top"><strong class="titulos_novedades">Seguro con Franquicia</strong></td>
            </tr>
            <tr>
              <td height="6" valign="top" class="separador"><img src="images/img_separador_novedades.png" alt="" width="3" height="3" /></td>
            </tr>
            <tr>
              <td valign="top" class="contenido_novedades">Ud. fija un 
                monto hasta donde se hace cargo del siniestro, y cuando 
                mayor es ese monto, menor es el costo del seguro.</td>
            </tr>
            <tr>
              <td height="22" class="contenido_novedades">&nbsp;</td>
            </tr>
            <tr>
              <td height="32" valign="top" class="titulos_novedades"><strong>Seguro Responsabilidad Compartida</strong></td>
            </tr>
            <tr>
              <td height="6" valign="top" class="separador"><img src="images/img_separador_novedades.png" alt="" width="3" height="3" /></td>
            </tr>
            <tr>
              <td valign="top" class="contenido_novedades">Los riesgos son compartidos, 
                en una proporcion que Ud. fija, entre el asegurado y 
                la compania.</td>
            </tr>
            <tr>
              <td height="22">&nbsp;</td>
            </tr>
            <tr>
              <td height="32" valign="top" class="titulos_novedades"><strong>Averig&uuml;e el costo de su veh&iacute;culo</strong></td>
            </tr>
            <tr>
              <td height="6" valign="top" class="separador"><img src="images/img_separador_novedades.png" alt="" width="3" height="3" /></td>
            </tr>
            <tr>
              <td height="54" valign="top"><div class="link_contenido">
                <p><span class="contenido_novedades">Complete el formulario 
                  y en la brevedad le estaremos enviando el presupuesto 
                  completo del seguro de su vehiculo. Haga </span><a href="#">click 
                    aqui</a></p>
                <p>&nbsp;</p>
              </div></td>
            </tr>
            <tr>
                                        
            <tr>
              <td height="90">&nbsp;</td>
            </tr>
          </table>
        <!-- InstanceEndEditable --></td>
      </tr>
      <tr>
        <td height="50" valign="top" bgcolor="#E5E5E5"><img src="images/img_titulo_PAGA-TU-POLIZA.png" width="198" height="42" /></td>
      </tr>
           <tr>
        <td bgcolor="#E5E5E5" height="70">
        <a href="http://www.webpagos.com.py/"><img src="images/logo-webpagos.png" alt="Ingresar a webpagos"/></a>
        
        </td>
      </tr>
      <tr>
    </table></td>
  </tr>
</table>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="42" background="images/img_fondo_pie.gif"><table width="650" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td height="18" align="center" class="datos_pie">Copyright &copy; <?php echo date("Y") ?> - El Comercio Paraguayo S.A. - Oficina Central: Alberdi N&ordm; 453</td>
      </tr>
      <tr>
        <td height="18" align="center"><div class="link_mail"><span class="datos_pie">Telefax.: (+595 21) 492   324 Rastreo   Autom&aacute;tico - Mail: <a href="mailto:elcomercioparaguayo@elcomercioparaguayo.com.py" target="_blank">elcomercioparaguayo@elcomercioparaguayo.com.py</a></span></div></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="46" align="center" valign="top" background="images/img_fondo_pie2.png"><table width="200" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td height="25" valign="bottom"><table width="78" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td width="78" class="datos_pie"><div class="link_mail"><a href="http://www.w3.com.py/" target="_blank">W3 IT Solutions</a></div></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>

</table>
<div id="imagen_bancard"><a href="https://www.bancard.com.py/webbancard/SOL/SelloECommBancard.html?c=rO7x6h.bVEGMA"><img src="images/logo_bancard.jpg" alt="bancard" width="224" height="89" /></a></div>
</body>
<!-- InstanceEnd --></html>
